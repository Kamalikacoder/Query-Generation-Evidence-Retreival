import xml.etree.ElementTree as ET

import requests

PUBMED_SEARCH_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
PUBMED_SUMMARY_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi"
PUBMED_FETCH_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
PUBMED_ARTICLE_URL = "https://pubmed.ncbi.nlm.nih.gov/{pmid}/"
REQUEST_TIMEOUT = 15
SEARCH_RESULT_BUFFER = 10
CLAIM_STOP_WORDS = {
    "is",
    "are",
    "by",
    "the",
    "a",
    "an",
    "in",
    "on",
    "for",
    "with",
    "used",
    "to",
    "commonly",
    "can",
    "be",
    "and",
    "of",
    "this",
    "that",
    "these",
    "those",
}


def _normalize_text(text):
    return (
        text.lower()
        .replace(",", " ")
        .replace(".", " ")
        .replace("(", " ")
        .replace(")", " ")
        .replace(":", " ")
        .replace(";", " ")
    )


def _extract_claim_keywords(claim):
    words = _normalize_text(claim).split()
    return {word for word in words if word.isalnum() and word not in CLAIM_STOP_WORDS}


def _parse_abstracts(xml_text):
    """Read PubMed abstract text from the efetch XML response."""
    abstracts_by_pmid = {}

    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return abstracts_by_pmid

    for article in root.findall(".//PubmedArticle"):
        pmid = article.findtext(".//PMID", default="").strip()
        abstract_nodes = article.findall(".//Abstract/AbstractText")

        abstract_parts = []
        for node in abstract_nodes:
            label = node.attrib.get("Label", "").strip()
            text = "".join(node.itertext()).strip()
            if not text:
                continue
            abstract_parts.append(f"{label}: {text}" if label else text)

        abstracts_by_pmid[pmid] = " ".join(abstract_parts)

    return abstracts_by_pmid


def _build_evidence_item(pmid, summary_data, abstracts_by_pmid):
    article = summary_data.get(pmid, {})
    authors = article.get("authors", [])

    return {
        "pmid": pmid,
        "title": article.get("title", "No title"),
        "abstract": abstracts_by_pmid.get(pmid, "") or "Abstract not available from PubMed.",
        "source": article.get("source", "Unknown"),
        "pubdate": article.get("pubdate", "Unknown"),
        "authors": [author.get("name", "") for author in authors if author.get("name")],
        "url": PUBMED_ARTICLE_URL.format(pmid=pmid),
    }


def _score_evidence_relevance(claim_keywords, evidence_item):
    title_words = set(_normalize_text(evidence_item["title"]).split())
    abstract_words = set(_normalize_text(evidence_item["abstract"]).split())

    title_overlap = len(claim_keywords.intersection(title_words))
    abstract_overlap = len(claim_keywords.intersection(abstract_words))
    relevance_score = (title_overlap * 2) + abstract_overlap

    return {
        "title_overlap": title_overlap,
        "abstract_overlap": abstract_overlap,
        "relevance_score": relevance_score,
    }


def _filter_relevant_evidence(claim, evidence_items, max_results):
    claim_keywords = _extract_claim_keywords(claim)
    if not claim_keywords:
        return evidence_items[:max_results]

    ranked_items = []
    for evidence_item in evidence_items:
        relevance = _score_evidence_relevance(claim_keywords, evidence_item)
        if relevance["title_overlap"] == 0 and relevance["abstract_overlap"] < 2:
            continue

        enriched_item = evidence_item.copy()
        enriched_item.update(relevance)
        ranked_items.append(enriched_item)

    ranked_items.sort(
        key=lambda item: (
            item["relevance_score"],
            item["title_overlap"],
            item["abstract_overlap"],
        ),
        reverse=True,
    )
    if ranked_items:
        return ranked_items[:max_results]

    fallback_items = []
    for evidence_item in evidence_items:
        relevance = _score_evidence_relevance(claim_keywords, evidence_item)
        enriched_item = evidence_item.copy()
        enriched_item.update(relevance)
        fallback_items.append(enriched_item)

    fallback_items.sort(
        key=lambda item: (
            item["relevance_score"],
            item["title_overlap"],
            item["abstract_overlap"],
        ),
        reverse=True,
    )
    return fallback_items[: min(max_results, 3)]


def _build_search_terms(claim, query):
    search_terms = []
    clean_query = query.strip()
    clean_claim = claim.strip()

    if clean_query:
        search_terms.append(clean_query)
        search_terms.append(f"{clean_query} treatment")
        search_terms.append(f"{clean_query} diagnosis")

    if clean_claim and clean_claim not in search_terms:
        search_terms.append(clean_claim)

    unique_terms = []
    for term in search_terms:
        if term and term not in unique_terms:
            unique_terms.append(term)

    return unique_terms


def _search_pubmed_ids(search_term, max_results):
    search_params = {
        "db": "pubmed",
        "term": search_term,
        "retmode": "json",
        "sort": "relevance",
        "retmax": max_results,
    }
    search_response = requests.get(PUBMED_SEARCH_URL, params=search_params, timeout=REQUEST_TIMEOUT)
    search_response.raise_for_status()
    return search_response.json().get("esearchresult", {}).get("idlist", [])


def retrieve_evidence(claim, query, max_results=5):
    """Fetch PubMed evidence and keep only items that are relevant to the claim."""
    try:
        ids = []
        for search_term in _build_search_terms(claim, query):
            ids = _search_pubmed_ids(search_term, SEARCH_RESULT_BUFFER)
            if ids:
                break

        if not ids:
            return []

        id_string = ",".join(ids)

        summary_params = {
            "db": "pubmed",
            "id": id_string,
            "retmode": "json",
        }
        summary_response = requests.get(PUBMED_SUMMARY_URL, params=summary_params, timeout=REQUEST_TIMEOUT)
        summary_response.raise_for_status()
        summary_data = summary_response.json().get("result", {})

        fetch_params = {
            "db": "pubmed",
            "id": id_string,
            "retmode": "xml",
            "rettype": "abstract",
        }
        fetch_response = requests.get(PUBMED_FETCH_URL, params=fetch_params, timeout=REQUEST_TIMEOUT)
        fetch_response.raise_for_status()
        abstracts_by_pmid = _parse_abstracts(fetch_response.text)

        raw_evidence = [_build_evidence_item(pmid, summary_data, abstracts_by_pmid) for pmid in ids]
        return _filter_relevant_evidence(claim, raw_evidence, max_results)
    except requests.RequestException as e:
        print(f"Network error retrieving evidence from PubMed: {e}")
        return []
    except Exception as e:
        print(f"Error retrieving evidence from PubMed: {e}")
        return []
