STOP_WORDS = {
    "is",
    "are",
    "by",
    "the",
    "a",
    "an",
    "in",
    "on",
    "for",
    "with",
    "used",
    "to",
    "commonly",
    "can",
    "be",
    "and",
    "of",
    "patient",
    "currently",
    "history",
    "has",
    "have",
    "had",
    "was",
    "were",
    "she",
    "he",
    "they",
    "it",
    "this",
    "that",
}


def _normalize_claim(claim):
    return (
        claim.lower()
        .replace(",", " ")
        .replace(".", " ")
        .replace("(", " ")
        .replace(")", " ")
        .replace(":", " ")
        .replace(";", " ")
    )


def generate_queries(claim):
    """Turn a claim into a compact PubMed-friendly search query."""
    words = _normalize_claim(claim).split()
    keywords = [word for word in words if word not in STOP_WORDS and word.isalnum()]

    if len(keywords) >= 2:
        return " ".join(keywords[:8])

    fallback_words = [word for word in words if word.isalnum()]
    if fallback_words:
        return " ".join(fallback_words[:8])

    return claim.strip()
