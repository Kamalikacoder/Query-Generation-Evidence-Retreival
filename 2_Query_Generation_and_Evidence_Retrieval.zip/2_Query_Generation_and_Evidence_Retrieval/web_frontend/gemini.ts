import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function decomposeClaims(summary: string) {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Split the following medical summary into individual, atomic factual claims. 
    Return a JSON array of strings.
    
    Summary: ${summary}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: { type: Type.STRING }
      }
    }
  });
  
  try {
    return JSON.parse(response.text || "[]") as string[];
  } catch (e) {
    console.error("Failed to parse claims", e);
    return [];
  }
}

export async function generateQuery(claim: string) {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Convert this medical claim into a concise PubMed search query (keywords only).
    
    Claim: ${claim}`,
  });
  
  return response.text?.trim() || claim;
}

export async function verifyClaim(claim: string, evidence: string) {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Compare the following medical claim with the provided evidence from PubMed.
    Determine if the claim is Supported, Not Supported, or Uncertain.
    Provide a confidence score between 0.0 and 1.0.
    
    Claim: ${claim}
    Evidence: ${evidence}
    
    Return JSON format: { "status": "Supported" | "Not Supported" | "Uncertain", "score": number, "reasoning": string }`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          status: { type: Type.STRING, enum: ["Supported", "Not Supported", "Uncertain"] },
          score: { type: Type.NUMBER },
          reasoning: { type: Type.STRING }
        },
        required: ["status", "score", "reasoning"]
      }
    }
  });
  
  try {
    return JSON.parse(response.text || "{}");
  } catch (e) {
    return { status: "Uncertain", score: 0.5, reasoning: "Error parsing verification" };
  }
}

export async function correctClaim(claim: string, evidence: string) {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `If the following medical claim is incorrect or unsupported, rewrite it to be accurate based on the evidence. If it is already correct, return it as is.
    
    Claim: ${claim}
    Evidence: ${evidence}`,
  });
  
  return response.text?.trim() || claim;
}
