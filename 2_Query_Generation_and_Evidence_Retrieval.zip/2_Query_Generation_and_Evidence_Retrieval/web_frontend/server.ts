import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import axios from "axios";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // PubMed API Proxy
  app.get("/api/pubmed/search", async (req, res) => {
    const { q } = req.query;
    if (!q) return res.status(400).json({ error: "Query is required" });

    try {
      // 1. Search for IDs
      const searchUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term=${encodeURIComponent(q as string)}&retmode=json&retmax=3`;
      const searchRes = await axios.get(searchUrl);
      const ids = searchRes.data.esearchresult.idlist;

      if (!ids || ids.length === 0) {
        return res.json({ results: [] });
      }

      // 2. Fetch Abstracts
      const fetchUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=${ids.join(",")}&retmode=xml&rettype=abstract`;
      const fetchRes = await axios.get(fetchUrl);
      
      // Note: Parsing XML in JS can be tricky. For a student project, 
      // we can use a simple regex or a library. 
      // Let's try to get JSON if possible, but efetch doesn't support JSON well for abstracts.
      // Alternatively, use esummary for titles and basic info.
      
      const summaryUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&id=${ids.join(",")}&retmode=json`;
      const summaryRes = await axios.get(summaryUrl);
      const summaries = summaryRes.data.result;

      const results = ids.map((id: string) => {
        const item = summaries[id];
        return {
          id,
          title: item.title,
          source: item.source,
          pubdate: item.pubdate,
          // We'll use the title and metadata as "evidence" for now, 
          // or we could try to scrape the abstract if needed.
          // For this demo, title + source is enough for lightweight verification.
          abstract: "Abstract available at PubMed ID: " + id
        };
      });

      res.json({ results });
    } catch (error) {
      console.error("PubMed API Error:", error);
      res.status(500).json({ error: "Failed to fetch from PubMed" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
